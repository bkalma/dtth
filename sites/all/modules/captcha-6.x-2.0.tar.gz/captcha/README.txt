
Please checkout the branch according to the version of Drupal you're running...

Drupal 4:
  DRUPAL-4-7

Drupal 5:
  DRUPAL-5--3

Drupal 6:
  DRUPAL-6--1

HEAD contains an experimental branch for Drupal 6
