VarInsert for SPAW Editor PHP Edition v.2
-------------------------------------------

These scripts are written for use with PHPMailer-ML when
using the SPAW Editor v.2. It is designed to add a menu option for
variable substitution within an email message body. To use it
you will require the file "inc.campaigns.php" for PHPMailer-ML
version 1.8.1a.
Author: Andy Prevost
License: GPL

Installation
------------
Copy "varinsert" directory into "plugins" subdir of your SPAW v.2 installation
