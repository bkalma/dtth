/* $Id$ */

A module that makes it possible to log in through third party API:s
supporting OAuth. Makes it possible for other modules to define OAuth API:s
which users should be able to log in through and also exposes that ability to
the user who can add new API connections through an admin page.