
General third party connection module for Drupal that makes it easier to
enable users to one click login (and register) through connect-services like
Facebook Connect, Twitter Connect or whatever some crazy developer decides to
create a submodule for.

Development sponsored by Good Old.