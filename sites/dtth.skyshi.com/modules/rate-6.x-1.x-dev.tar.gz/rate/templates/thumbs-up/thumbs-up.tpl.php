<?php
/**
 * @file
 * Rate widget theme
 */

print $up_button;

if ($info) {
  print '<div class="rate-info">' . $info . '</div>';
}

?>